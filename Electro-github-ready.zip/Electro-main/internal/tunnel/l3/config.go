package l3

import (
	"fmt"
	"net"
	"strings"

	"github.com/Devipix/Electro/config"
	"github.com/Devipix/Electro/internal/tunnel/mssclamp"
	"github.com/Devipix/Electro/internal/tunnel/portmap"
	"github.com/Devipix/Electro/internal/utils/network"
)

// Which end dials. A layer-3 tunnel is symmetric once it is up — both ends
// send and receive the same way — so this decides only who reaches out and who
// waits, which is the whole of the direct/reverse question at this layer.
const (
	// ModeDial reaches out to a peer. This is the Iran side of a direct
	// tunnel: it needs no inbound port of its own.
	ModeDial = "dial"

	// ModeListen waits to be dialled.
	ModeListen = "listen"
)

const (
	// defaultIfaceName is the interface created when the config does not name
	// one.
	defaultIfaceName = "bp0"

	// defaultMTU is deliberately conservative. The arithmetic in MTUFor
	// produces something near 1448 on an unobstructed path, but the effective
	// MTU of a real route is frequently below 1500 — a tunnel somewhere
	// upstream, a PPPoE link, an encapsulating provider — and a layer-3 tunnel
	// whose packets are a little too large does not fail loudly. It drops the
	// large flows and passes the small ones, which presents as "downloads
	// stall but ping works" and costs an afternoon to diagnose. Starting low
	// and letting an operator raise it is the cheaper default.
	defaultMTU = 1400

	// defaultTxQueueLen is how many packets the kernel may hold for the
	// interface while this process is draining it. See configureInterface for
	// why the device's own default of 500 is too shallow here, and Config's
	// TxQueueLen for why deeper is not simply better.
	defaultTxQueueLen = 4096

	// defaultQdisc bounds the time a packet may sit in that queue. See
	// Config.Qdisc.
	defaultQdisc = "fq_codel"

	// minMTU is below anything workable; IPv6 alone requires 1280.
	minMTU = 576

	// maxMTU bounds the read buffers.
	maxMTU = 9000
)

// Config is one resolved layer-3 tunnel, already validated.
type Config struct {
	// Mode is ModeDial or ModeListen.
	Mode string

	// Addr is the peer to dial, or the address to bind, depending on Mode. On
	// a kernel GRE carrier it is the other server's address on both sides, with
	// no port: a GRE link names both ends and neither of them listens.
	Addr string

	// GRELocal is this server's own address for a kernel GRE link. Empty uses
	// the source address of the route to Addr, which is right unless the
	// server has several and the other end expects a particular one.
	GRELocal string

	// Token is the shared secret both ends hold. It is the only credential.
	Token string

	// Carrier names the datagram carrier beneath the tunnel, or one of the two
	// kernel GRE links (gre, ip6gre), which have no carrier socket at all —
	// see kernelgre.go.
	Carrier string

	// Encap names the framing. There is one: "gre". A config that still says
	// "ipip" is read as GRE — see NewEncap.
	Encap string

	// GREKey is the RFC 2890 key. Zero omits the field entirely. On a kernel
	// GRE carrier it is the kernel link's key, which is what lets more than one
	// GRE tunnel join the same two servers.
	GREKey uint32

	// Iface is the TUN interface name to create.
	Iface string

	// LocalIP is this end's address on the tunnel, with or without a prefix.
	LocalIP string

	// PeerIP is the other end's address on the tunnel.
	PeerIP string

	// MTU is the interface MTU. Zero takes defaultMTU.
	MTU int

	// SockBuf sizes the carrier's socket buffers. Zero takes the carrier
	// default.
	SockBuf int

	// FEC adds forward error correction over whichever carrier is in use: for
	// every FEC.Data datagrams, FEC.Parity extra ones, and any FEC.Parity of a
	// group may be lost without loss. Zero values mean none. See fec.go.
	FEC FECConfig

	// TxQueueLen is how many packets the kernel may hold for the interface
	// while this process drains it. Zero takes the default.
	//
	// Deeper is not better. A queue is latency: 4096 packets of 1400 bytes is
	// 5.7 MB, and on a 100 Mbit/s link a full one is most of half a second of
	// delay before a packet is even sent. That delay is the jitter. Deep queues
	// stop drops under a burst and cause bufferbloat the rest of the time, and
	// the way out of that trade is not a number but Qdisc below.
	TxQueueLen int

	// Qdisc is the queueing discipline put on the interface. Empty takes the
	// default, which is fq_codel.
	//
	// This is the setting that actually decides jitter. Plain fq paces and
	// shares fairly but lets the queue grow to whatever the length allows;
	// fq_codel measures how long packets are sitting there and starts dropping
	// when the delay climbs, which keeps the queue short without giving up
	// throughput. It is the standard answer to bufferbloat and it is why the
	// queue can be deep and the latency still low.
	Qdisc string

	// AutoMTU lets the tunnel measure the path once it is up and set the
	// interface to what it actually carries, instead of trusting the figure in
	// the file. See mtuprobe.go — this is the setting that fails worst when it
	// is wrong, and the only one that cannot be worked out from the config.
	AutoMTU bool

	// MSSClamp caps the TCP segment size of connections crossing the tunnel.
	// Zero derives it from the MTU, which is what almost every tunnel wants;
	// a positive value sets it explicitly; -1 turns clamping off. See
	// mss_linux.go for why the default is on.
	MSSClamp int

	// Ports are forwarded port mappings served over the tunnel, in the same
	// syntax the reverse tunnel uses. Empty means the tunnel carries routed
	// traffic only, which is the plain layer-3 case.
	Ports []string

	// AcceptUDP forwards UDP as well as TCP on the mapped ports. Off unless
	// asked for: a forwarded port carries TCP until an operator says
	// otherwise, for the same reason it does on the reverse tunnel.
	AcceptUDP bool
	// UDPOnly opens no TCP listener on the mapped ports (port_protocol = "udp").
	UDPOnly bool

	// MaxConnections caps simultaneous forwarded connections (0 = unlimited).
	// It applies to the forwarder only: the tunnel itself carries whatever the
	// kernel routes into the interface, which has no connections to count.
	MaxConnections int

	// BandwidthMbps caps forwarded throughput in Mbit/s (0 = unlimited). Same
	// scope as MaxConnections, and for the same reason.
	BandwidthMbps int

	// Spoof tunes the forged-source carrier. Ignored unless Carrier is
	// "spoof". It is the same type the reverse transports take, so the keys an
	// operator already knows mean the same thing here.
	Spoof config.SpoofConfig

	// Pck tunes the packet-level TCP carrier. Ignored unless Carrier is
	// "pck" or "sni", and every field is optional: the carrier works out its
	// own egress from the route to the peer.
	Pck network.PcapCarrier

	// Preset is the tuning profile's name (balance, turbo, aggressive). It is
	// a label for every carrier but pck, whose engine takes the parameters
	// the keys below leave unset from it. See paqet.PresetParams.
	Preset string

	// The PCK engine's own tuning; zero means the preset's. Read only when
	// Carrier is "pck".
	PckConns                   int
	PckKCPMode                 string
	PckKCPMTU                  int
	PckKCPSndWnd, PckKCPRcvWnd int
	PckKCPBlock                string
	// PckRemoteTargets lets the listening side dial targets that are not its
	// own addresses. See paqet.Config.RemoteTargets.
	PckRemoteTargets bool

	// SNIDomain is the server name the "sni" carrier puts in the ClientHello it
	// sends at the start of the flow. Empty means snispoof.DefaultDomain.
	// Ignored by every other carrier.
	SNIDomain string
}

// Validate fills in what was left out and refuses what cannot work. It is
// called before anything is opened, so a bad config costs nothing.
func (c *Config) Validate() error {
	c.Mode = strings.ToLower(strings.TrimSpace(c.Mode))
	switch c.Mode {
	case ModeDial, ModeListen:
	case "":
		return fmt.Errorf("l3: mode is required (%q or %q)", ModeDial, ModeListen)
	default:
		return fmt.Errorf("l3: unknown mode %q (want %q or %q)", c.Mode, ModeDial, ModeListen)
	}

	// Lower-cased first: whether this is a kernel GRE link decides what addr
	// and token have to be.
	c.Carrier = strings.ToLower(strings.TrimSpace(c.Carrier))
	kernel := KernelCarrier(c.Carrier)

	if strings.TrimSpace(c.Addr) == "" {
		switch {
		case kernel:
			return fmt.Errorf("l3: addr is required and must be the other server's address")
		case c.Mode == ModeDial:
			return fmt.Errorf("l3: addr is required and must be the peer's host:port")
		}
		return fmt.Errorf("l3: addr is required and must be the address to bind")
	}
	if kernel {
		// A GRE link has no port, and no secret: the kernel sends whatever
		// reaches the interface, in the clear. A token in the file is ignored.
		if err := c.validateGREEndpoints(); err != nil {
			return err
		}
	} else {
		if _, _, err := net.SplitHostPort(c.Addr); err != nil {
			return fmt.Errorf("l3: addr %q must be host:port: %w", c.Addr, err)
		}
		if strings.TrimSpace(c.Token) == "" {
			return fmt.Errorf("l3: token is required and must match the other end")
		}
	}

	if _, err := NewEncap(c.Encap, c.GREKey); err != nil {
		return err
	}
	// Normalised to what is actually used, so everything downstream — the
	// handshake identifier included — names the same thing the packets are
	// wrapped in.
	c.Encap = "gre"
	// Before the known-carrier check, so a tunnel on a carrier that was taken
	// out is told so — and told what to pick — instead of reading as a typo.
	// An empty name is one of them: it used to mean udp, and filling in another
	// carrier here would move a working tunnel onto a different wire format
	// that the other end is not speaking.
	if !knownCarrier(c.Carrier) {
		if RemovedCarrier(c.Carrier) {
			return RemovedCarrierError(c.Carrier)
		}
		return fmt.Errorf("l3: carrier %q is not available (have %s)",
			c.Carrier, strings.Join(Carriers(), ", "))
	}
	// The listening side of the forged-source carrier cannot learn where its
	// peer really is, because every packet it receives carries a forged
	// source. Catching that here beats a tunnel that comes up and sends its
	// replies nowhere.
	if c.Carrier == CarrierSpoof && c.Mode == ModeListen && c.Spoof.SpoofPeerIP == "" {
		return fmt.Errorf("l3: carrier %q needs spoof_peer_ip when listening, "+
			"because the peer forges the source of every packet it sends", CarrierSpoof)
	}
	// PCK is its own engine and reads a different set of keys. Everything below
	// is about the TUN device and the session, which it has neither of, and a
	// file written for the previous PCK must not be refused for what it says
	// about them.
	if c.Carrier == CarrierPck {
		return c.validatePck()
	}
	// The scheme is not negotiated, so an unusable one is refused where it is
	// written rather than at the first packet the peer cannot rebuild.
	if err := c.FEC.Validate(); err != nil {
		return err
	}
	if c.Iface == "" {
		c.Iface = defaultIfaceName
	}

	if err := validateTunnelAddr("local_ip", c.LocalIP, true); err != nil {
		return err
	}
	if c.PeerIP != "" {
		if err := validateTunnelAddr("peer_ip", c.PeerIP, false); err != nil {
			return err
		}
	}
	if !strings.Contains(c.LocalIP, "/") && c.PeerIP == "" {
		return fmt.Errorf("l3: local_ip %q has no prefix length, so peer_ip is required", c.LocalIP)
	}
	if err := CheckTunnelEnds(c.LocalIP, c.PeerIP); err != nil {
		return err
	}

	if c.TxQueueLen <= 0 {
		c.TxQueueLen = defaultTxQueueLen
	}
	if c.TxQueueLen > 1<<20 {
		return fmt.Errorf("l3: txqueuelen %d is absurd; a queue that deep is latency, not capacity", c.TxQueueLen)
	}
	if c.Qdisc == "" {
		c.Qdisc = defaultQdisc
	}
	// On a kernel GRE link zero stays zero: the engine works it out from the
	// interface the route to the other server leaves by, minus what GRE adds,
	// which is a better figure than any default (see greMTUFor).
	if c.MTU == 0 && !kernel {
		c.MTU = defaultMTU
	}
	if c.MTU != 0 && (c.MTU < minMTU || c.MTU > maxMTU) {
		return fmt.Errorf("l3: mtu %d is outside the workable range %d..%d", c.MTU, minMTU, maxMTU)
	}
	// A clamp larger than the MTU can carry is not a clamp; it would leave the
	// stall it exists to prevent, while looking like it had been dealt with.
	if c.MSSClamp > 0 && c.MTU != 0 && c.MSSClamp > c.MTU-mssclamp.OverheadV4 {
		return fmt.Errorf("l3: mss_clamp %d does not fit an mtu of %d (the largest that fits is %d)",
			c.MSSClamp, c.MTU, c.MTU-mssclamp.OverheadV4)
	}
	if c.MSSClamp < 0 && c.MSSClamp != mssclamp.Off {
		return fmt.Errorf("l3: mss_clamp %d is not a size (use 0 for automatic, or %d to turn it off)",
			c.MSSClamp, mssclamp.Off)
	}

	// Expanded here purely to reject a bad mapping before anything is opened.
	// The forwarder expands them again for real; doing it twice costs nothing
	// and means a typo is a startup error rather than a half-served config.
	if len(c.Ports) > 0 {
		if _, err := portmap.Expand(c.Ports, c.PeerIP); err != nil {
			return fmt.Errorf("l3: %w", err)
		}
	}
	return nil
}

// validateTunnelAddr checks one of the two addresses the interface is given.
// The local one may carry a prefix; the peer one may not, because it names a
// single host.
func validateTunnelAddr(field, value string, allowPrefix bool) error {
	value = strings.TrimSpace(value)
	if value == "" {
		return fmt.Errorf("l3: %s is required (this end's address on the tunnel, e.g. \"10.10.0.1/30\")", field)
	}
	if strings.Contains(value, "/") {
		if !allowPrefix {
			return fmt.Errorf("l3: %s %q must be a bare address, without a prefix length", field, value)
		}
		if _, _, err := net.ParseCIDR(value); err != nil {
			return fmt.Errorf("l3: %s %q is not a valid address/prefix: %w", field, value, err)
		}
		return nil
	}
	if net.ParseIP(value) == nil {
		return fmt.Errorf("l3: %s %q is not a valid IP address", field, value)
	}
	return nil
}

// MTUFor is the largest interface MTU that fits inside a path without
// fragmenting:
//
//	path − carrier − session − encapsulation
//
// It is what the operator should be told when their configured MTU is larger
// than the path can carry, and what a future automatic mode would set. It is
// reported rather than imposed, because the path MTU is a guess and a wrong
// guess that silently lowers the interface is worse than a number an operator
// can see and argue with.
func MTUFor(pathMTU, carrierOverhead, encapOverhead int) int {
	return pathMTU - carrierOverhead - dataOverhead - encapOverhead
}

// CheckTunnelEnds refuses a config whose two tunnel addresses are the same.
//
// peer_ip is the OTHER machine's address, and the wizard asks for both, one
// after the other, with the values swapped between the two machines. Typing
// this machine's address twice gave a tunnel that came up, completed its
// handshake and then carried nothing — every packet for the peer was routed to
// itself — with no error anywhere to say why. Seen in the field on a kharej
// set up as "10.10.2.2/30 ↔ 10.10.2.2".
func CheckTunnelEnds(localIP, peerIP string) error {
	local, _, _ := strings.Cut(strings.TrimSpace(localIP), "/")
	peer, _, _ := strings.Cut(strings.TrimSpace(peerIP), "/")
	if peer != "" && local == peer {
		return fmt.Errorf("l3: local_ip and peer_ip are both %s. peer_ip is the other machine's "+
			"address on the tunnel — the one the other server has as its local_ip — "+
			"so the two must differ", local)
	}
	return nil
}

// ConfigFromTable maps the on-disk table to the settings used at startup and validation.
func ConfigFromTable(table config.L3Config) (Config, error) {
	tunnelCfg := Config{
		Mode:           table.Mode,
		Addr:           table.Addr,
		GRELocal:       table.GRELocal,
		Token:          table.Token,
		Carrier:        table.Carrier,
		Encap:          table.Encap,
		GREKey:         table.GREKey,
		Iface:          table.Iface,
		LocalIP:        table.LocalIP,
		PeerIP:         table.PeerIP,
		MTU:            table.MTU,
		SockBuf:        table.SockBuf,
		TxQueueLen:     table.TxQueueLen,
		Qdisc:          table.Qdisc,
		MSSClamp:       table.MSSClamp,
		AutoMTU:        table.AutoMTUEnabled(),
		Ports:          table.Ports,
		AcceptUDP:      table.ForwardsUDP(),
		UDPOnly:        !table.ForwardsTCP(),
		MaxConnections: table.MaxConnections,
		BandwidthMbps:  table.BandwidthMbps,
		// Read only by the carrier they belong to; ignored otherwise.
		Preset:           table.Preset,
		PckConns:         table.PckConns,
		PckKCPMode:       table.PckKCPMode,
		PckKCPMTU:        table.PckKCPMTU,
		PckKCPSndWnd:     table.PckKCPSndWnd,
		PckKCPRcvWnd:     table.PckKCPRcvWnd,
		PckKCPBlock:      table.PckKCPBlock,
		PckRemoteTargets: table.PckRemoteTargets,
		FEC:              FECConfig{Data: table.FECData, Parity: table.FECParity},
		Spoof:            table.SpoofConfig,
		SNIDomain:        table.SNIDomain,
		Pck: network.PcapCarrier{
			Interface:  table.PckInterface,
			GatewayMAC: table.PckGatewayMAC,
		},
	}

	// Parsed rather than passed through, so a typo in the flag cycle is
	// reported here instead of becoming an empty cycle the carrier silently
	// replaces with its default.
	if len(table.PckFlags) > 0 {
		flags, err := network.ParseTCPFlagList(table.PckFlags)
		if err != nil {
			return Config{}, fmt.Errorf("pck_flags: %w", err)
		}
		tunnelCfg.Pck.Flags = flags
	}
	return tunnelCfg, nil
}
