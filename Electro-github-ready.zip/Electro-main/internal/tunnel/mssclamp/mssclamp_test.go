package mssclamp

import (
	"strings"
	"testing"
)

// The command line, not the rule description.
//
// This is the test that was missing. The old code kept the whole command in one
// slice and wrote the verb over index 2 — which held the chain — so every
// invocation came out as "iptables -t mangle -A -o bp0 ..." with no chain at
// all. iptables refused all of them and the refusal was logged at debug level,
// so the clamp was absent from every machine while the code that built it
// passed its tests: they only ever inspected the description, never the argv
// that would actually be run.
func TestTheCommandLineIsWellFormed(t *testing.T) {
	rules := Rules("l3", "bp0", 1400, 0)
	if len(rules) != 4 {
		t.Fatalf("got %d rules, want 4 (two chains x two families)", len(rules))
	}

	for _, r := range rules {
		for _, verb := range []string{"-A", "-D", "-C"} {
			args := r.Args(verb)

			// iptables takes: -t <table> <verb> <chain> <match...> <target...>
			if len(args) < 5 {
				t.Fatalf("%s %v: too short to be a command", r.Cmd, args)
			}
			if args[0] != "-t" || args[1] != r.Table {
				t.Errorf("%s: does not start with the table: %v", r.Cmd, args[:2])
			}
			if args[2] != verb {
				t.Errorf("%s: verb slot holds %q, want %q", r.Cmd, args[2], verb)
			}
			// The one that broke: the chain must survive the verb.
			if args[3] != r.Chain {
				t.Errorf("%s %s: chain slot holds %q, want %q — the verb displaced it",
					r.Cmd, verb, args[3], r.Chain)
			}
			if r.Chain != "FORWARD" && r.Chain != "OUTPUT" {
				t.Errorf("unexpected chain %q", r.Chain)
			}

			// And nothing may be lost from the match.
			line := strings.Join(args, " ")
			for _, want := range []string{"-o bp0", "-p tcp", "--tcp-flags SYN,RST SYN", "-j TCPMSS", "--set-mss"} {
				if !strings.Contains(line, want) {
					t.Errorf("%s %s: missing %q in %q", r.Cmd, verb, want, line)
				}
			}
		}
	}
}

// Add and delete must describe the same rule, or the sweep cannot find what the
// add created and rules accumulate — which is the fault this whole shape exists
// to prevent.
func TestAddAndDeleteMatchExactly(t *testing.T) {
	for _, r := range Rules("gre", "gre1", 1400, 0) {
		add := r.Args("-A")
		del := r.Args("-D")
		if len(add) != len(del) {
			t.Fatalf("add and delete differ in length: %v vs %v", add, del)
		}
		for i := range add {
			if i == 2 {
				continue // the verb, which is the only difference
			}
			if add[i] != del[i] {
				t.Errorf("add and delete differ at %d: %q vs %q", i, add[i], del[i])
			}
		}
	}
}

// Each tunnel kind tags its own rules, so two kinds on one host cannot sweep
// each other's away.
func TestRulesAreTaggedPerKindAndInterface(t *testing.T) {
	l3 := strings.Join(Rules("l3", "bp0", 1400, 0)[0].Args("-A"), " ")
	gre := strings.Join(Rules("gre", "gre1", 1400, 0)[0].Args("-A"), " ")

	if !strings.Contains(l3, "electro-l3-mss-bp0") {
		t.Errorf("l3 rule is not tagged: %s", l3)
	}
	if !strings.Contains(gre, "electro-gre-mss-gre1") {
		t.Errorf("gre rule is not tagged: %s", gre)
	}
	if strings.Contains(l3, "gre1") || strings.Contains(gre, "bp0") {
		t.Error("the two kinds' rules name each other's interfaces")
	}
}

func TestValueIsDerivedFromTheMTU(t *testing.T) {
	if got := For(0, 1400, OverheadV4); got != 1360 {
		t.Errorf("automatic IPv4 clamp for mtu 1400 = %d, want 1360", got)
	}
	if got := For(0, 1400, OverheadV6); got != 1340 {
		t.Errorf("automatic IPv6 clamp for mtu 1400 = %d, want 1340", got)
	}
	if got := For(1208, 1400, OverheadV4); got != 1208 {
		t.Errorf("explicit clamp = %d, want 1208", got)
	}
}

// An MTU too small to leave room for a segment must produce no rule at all,
// rather than one with a nonsensical size.
func TestNoRuleWhenNothingFits(t *testing.T) {
	for _, r := range Rules("l3", "bp0", 30, 0) {
		if r.MSS <= 0 {
			t.Fatalf("a rule was built with mss %d", r.MSS)
		}
	}
}

// Apply must tolerate a nil logger on every path, including the one that
// returns early.
//
// It did not, and the shape of the bug is worth remembering: the nil guard sat
// below the early return for Off, so the single combination of "no logger" and
// "clamping turned off" walked straight past the check that existed to prevent
// it. Locally it passed, because the non-Linux build of Apply does nothing at
// all; CI runs Linux and panicked.
func TestApplyToleratesANilLogger(t *testing.T) {
	// Off is the path that used to panic.
	Apply("l3", "bp0", 1400, Off, nil)
	Remove("l3", "bp0", 1400, Off)

	// And the ordinary path, which reaches iptables and is expected to fail in
	// a test environment — failing is fine, panicking is not.
	Apply("l3", "bp0-test-nonexistent", 1400, 0, nil)
	Remove("l3", "bp0-test-nonexistent", 1400, 0)
}

// One log line per address family, not per rule. Each family installs into two
// chains with the same MSS, and the old Apply logged every one of them.
func TestGroupReportsEachFamilyOnce(t *testing.T) {
	rules := Rules("l3", "bp0", 1400, 0)
	if len(rules) != 4 {
		t.Fatalf("want 4 rules (2 families x 2 chains), got %d", len(rules))
	}
	got := Group(rules)
	if len(got) != 2 {
		t.Fatalf("want 2 families, got %d: %+v", len(got), got)
	}
	for _, c := range got {
		if len(c.Chains) != 2 {
			t.Errorf("%s: want both chains, got %v", c.Label, c.Chains)
		}
	}
	if got[0].Label != "IPv4" || got[0].MSS != 1400-OverheadV4 {
		t.Errorf("first family = %+v, want IPv4 at %d", got[0], 1400-OverheadV4)
	}
	if got[1].Label != "IPv6" || got[1].MSS != 1400-OverheadV6 {
		t.Errorf("second family = %+v, want IPv6 at %d", got[1], 1400-OverheadV6)
	}
}

// A chain that failed to install must not be named in the summary.
func TestGroupOnlyNamesInstalledChains(t *testing.T) {
	rules := Rules("l3", "bp0", 1400, 0)
	got := Group(rules[:1])
	if len(got) != 1 || len(got[0].Chains) != 1 || got[0].Chains[0] != "FORWARD" {
		t.Fatalf("got %+v, want one IPv4 entry on FORWARD only", got)
	}
	if Group(nil) != nil {
		t.Errorf("Group(nil) should be empty")
	}
}
