# Server layout (file locations)

Everything lives in a tidy, predictable layout. You can also see this any time
from **Manage → File Locations** in the CLI.

| Path | What |
|------|------|
| `/root/Electro` | The release bundle and downloaded archives. |
| `/root/Electro/backups` | [Backup](backup-restore.md) `.tar.gz` files. |
| `/etc/electro` | Tunnel configs (one `.toml` per tunnel) and runtime state. |
| `/usr/local/bin/electro` | The binary itself. |
| `electro-<name>.service` | A systemd unit per tunnel. |
| `electro-monitor.service` | The [monitor service](monitor-service.md). |

The install directory is recorded in `/etc/electro/install_path`, which is what
the uninstaller reads to know what to remove.

---

<div dir="rtl">

## خلاصهٔ فارسی

همه‌چیز در یک ساختار مرتب و قابل‌پیش‌بینی است. همین را هر وقت خواستی از
`Manage → File Locations` در CLI هم می‌بینی.

`‎/root/Electro` بستهٔ ریلیز و آرشیوهای دانلودشده ·
`‎/root/Electro/backups` فایل‌های [پشتیبان](backup-restore.md) ·
`‎/etc/electro` کانفیگ تونل‌ها (برای هر تونل یک فایل `.toml`) و وضعیت اجرا ·
`‎/usr/local/bin/electro` خودِ باینری ·
`electro-<name>.service` یک یونیت systemd به‌ازای هر تونل ·
`electro-monitor.service` [سرویس مانیتور](monitor-service.md).

مسیر نصب در `/etc/electro/install_path` ثبت می‌شود و حذف‌کنندهٔ داخلی از روی
همان می‌فهمد چه چیزی را پاک کند.

</div>

---
[← Back to the docs index](README.md)

---

*Last verified against Electro v2.0.0.*
